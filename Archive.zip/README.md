## What is Task Board?

Building an interface for Task Board.

## What features does Task Board bring?

The following are features that come with Task Board:
- Offline Mode with effective cache policies.
- Dark Theme support.
- Service Worker with effective precache policies that is easily configurable.
- Well Tailored, ensured to run & look well on Desktop, Android & iOS.
- More to come!
