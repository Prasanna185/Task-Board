export { default } from './Logo.component';
