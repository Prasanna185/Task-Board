export { default } from './Image.component';
