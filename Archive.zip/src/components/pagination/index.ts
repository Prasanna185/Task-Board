export { default } from './Pagination.component';
