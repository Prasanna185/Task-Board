import React from 'react';
import TaskBoard from 'routes/taskBoard';

export default function Home(): JSX.Element {
  return <TaskBoard />;
}
